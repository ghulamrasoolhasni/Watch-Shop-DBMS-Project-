const mysql= require('mysql')
const connection = mysql.createConnection({ 
    host: 'localhost',
    user: 'root',
    password: 'grhgrh092092',
    database: 'watchshop'
    });

module.exports = connection;