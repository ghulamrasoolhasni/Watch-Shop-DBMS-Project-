const connection=require('./connection');
connection.connect(function (err) {
    if (err) throw err; 
    connection.query("Select * from watches", (err, result) => {
        if (err) throw err;
        const data=result;
        console.log(data);
    });
});

const express=require('express')
const app=express()
const bodyParser =require('body-parser')
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.get('/', (req, res)=>{
    res.send(__dirname+'/index.html')
})
app.post('/', (req, res)=>{ 
    console.log(req.body);
})
app.listen(7000)


