create database watchshop;
use watchshop;
CREATE TABLE customers (
  CustomerID INT PRIMARY KEY,
  FirstName VARCHAR(50) NOT NULL,
  LastName VARCHAR(50) NOT NULL,
  Email VARCHAR(100) NOT NULL,
  Address VARCHAR(255) NOT NULL,
  City VARCHAR(100) NOT NULL,
  State VARCHAR(100) NOT NULL,
  ZipCode VARCHAR(20) NOT NULL,
  Country VARCHAR(100) NOT NULL
);

CREATE TABLE sales (
  SaleID INT PRIMARY KEY,
  OrderID INT NOT NULL,
  TotalAmount DECIMAL(10,2) NOT NULL,
  SaleDate TIMESTAMP NOT NULL,
  FOREIGN KEY (OrderID) REFERENCES orders(OrderID)
);

CREATE TABLE watches (
  WatchID INT PRIMARY KEY,
  Brand VARCHAR(100) NOT NULL,
  Model VARCHAR(100) NOT NULL,
  Gender ENUM('Men', 'Women') NOT NULL,
  Price DECIMAL(10,2) NOT NULL,
  Description TEXT,
  ImageURL VARCHAR(255)
);

CREATE TABLE users (
  UserID INT PRIMARY KEY,
  Username VARCHAR(50) NOT NULL,
  Password VARCHAR(100) NOT NULL,
  CustomerID INT,
  FOREIGN KEY (CustomerID) REFERENCES customers(CustomerID)
);

CREATE TABLE orders (
  OrderID INT PRIMARY KEY,
  CustomerID INT NOT NULL,
  WatchID INT NOT NULL,
  OrderDate DATE NOT NULL,
  FOREIGN KEY (CustomerID) REFERENCES customers(CustomerID),
  FOREIGN KEY (WatchID) REFERENCES watches(WatchID)
);

CREATE TABLE inventoryadjustments (
  AdjustmentID INT PRIMARY KEY,
  WatchID INT NOT NULL,
  AdjustmentDate DATE NOT NULL,
  QuantityChange INT NOT NULL,
  AdjustmentType VARCHAR(20) NOT NULL,
  FOREIGN KEY (WatchID) REFERENCES watches(WatchID)
);

-- -------------------PROCEDURES--------------------------
DELIMITER //
CREATE PROCEDURE AddCustomer (
  IN p_FirstName VARCHAR(50),
  IN p_LastName VARCHAR(50),
  IN p_Email VARCHAR(100),
  IN p_Address VARCHAR(255),
  IN p_City VARCHAR(100),
  IN p_State VARCHAR(100),
  IN p_ZipCode VARCHAR(20),
  IN p_Country VARCHAR(100)
)
BEGIN
  INSERT INTO customers (FirstName, LastName, Email, Address, City, State, ZipCode, Country)
  VALUES (p_FirstName, p_LastName, p_Email, p_Address, p_City, p_State, p_ZipCode, p_Country);
END //
DELIMITER ;
-- --------------------------------------
DELIMITER //
CREATE PROCEDURE UpdateCustomer (
  IN p_CustomerID INT,
  IN p_FirstName VARCHAR(50),
  IN p_LastName VARCHAR(50),
  IN p_Email VARCHAR(100),
  IN p_Address VARCHAR(255),
  IN p_City VARCHAR(100),
  IN p_State VARCHAR(100),
  IN p_ZipCode VARCHAR(20),
  IN p_Country VARCHAR(100)
)
BEGIN
  UPDATE customers
  SET FirstName = p_FirstName, LastName = p_LastName, Email = p_Email, Address = p_Address, 
      City = p_City, State = p_State, ZipCode = p_ZipCode, Country = p_Country
  WHERE CustomerID = p_CustomerID;
END //
DELIMITER ;
-- ------------------------------
DELIMITER //
CREATE PROCEDURE ViewAllCustomers ()
BEGIN
  SELECT * FROM customers;
END //
DELIMITER ;
-- -----------------------------------------------------
DELIMITER //
CREATE PROCEDURE AddWatch (
  IN p_Brand VARCHAR(100),
  IN p_Model VARCHAR(100),
  IN p_Gender ENUM('Men', 'Women'),
  IN p_Price DECIMAL(10,2),
  IN p_Description TEXT,
  IN p_ImageURL VARCHAR(255)
)
BEGIN
  INSERT INTO watches (Brand, Model, Gender, Price, Description, ImageURL)
  VALUES (p_Brand, p_Model, p_Gender, p_Price, p_Description, p_ImageURL);
END //
DELIMITER ;
-- ----------------------------------------------------
DELIMITER //
CREATE PROCEDURE UpdateWatch (
  IN p_WatchID INT,
  IN p_Brand VARCHAR(100),
  IN p_Model VARCHAR(100),
  IN p_Gender ENUM('Men', 'Women'),
  IN p_Price DECIMAL(10,2),
  IN p_Description TEXT,
  IN p_ImageURL VARCHAR(255)
)
BEGIN
  UPDATE watches
  SET Brand = p_Brand, Model = p_Model, Gender = p_Gender, Price = p_Price, 
      Description = p_Description, ImageURL = p_ImageURL
  WHERE WatchID = p_WatchID;
END //
DELIMITER ;
-- ----------------------------------
DELIMITER //
CREATE PROCEDURE DeleteWatch (
  IN p_WatchID INT
)
BEGIN
  DELETE FROM watches WHERE WatchID = p_WatchID;
END //
DELIMITER ;
-- --------------------------
DELIMITER //
CREATE PROCEDURE ViewAllWatches ()
BEGIN
  SELECT * FROM watches;
END //
DELIMITER ;
-- -------------------------------------
DELIMITER //
CREATE PROCEDURE RecordSale (
  IN p_OrderID INT,
  IN p_TotalAmount DECIMAL(10,2),
  IN p_SaleDate TIMESTAMP
)
BEGIN
  INSERT INTO sales (OrderID, TotalAmount, SaleDate)
  VALUES (p_OrderID, p_TotalAmount, p_SaleDate);
END //
DELIMITER ;
-- -------------------------------
DELIMITER //
CREATE PROCEDURE ViewAllSales ()
BEGIN
  SELECT * FROM sales;
END //
DELIMITER ;
-- --------------------------------------
DELIMITER //
CREATE PROCEDURE CreateOrder (
  IN p_CustomerID INT,
  IN p_WatchID INT,
  IN p_OrderDate DATE
)
BEGIN
  INSERT INTO orders (CustomerID, WatchID, OrderDate)
  VALUES (p_CustomerID, p_WatchID, p_OrderDate);
END //
DELIMITER ;
-- -------------------------
DELIMITER //
CREATE PROCEDURE DeleteOrder (
  IN p_OrderID INT
)
BEGIN
  DELETE FROM orders WHERE OrderID = p_OrderID;
END //
DELIMITER ;
-- ----------------------
DELIMITER //
CREATE PROCEDURE ViewAllOrders ()
BEGIN
  SELECT * FROM orders;
END //
DELIMITER ;
-- ----------------------------------------
DELIMITER //
CREATE PROCEDURE AddUser (
  IN p_Username VARCHAR(50),
  IN p_Password VARCHAR(100),
  IN p_CustomerID INT
)
BEGIN
  INSERT INTO users (Username, Password, CustomerID)
  VALUES (p_Username, p_Password, p_CustomerID);
END //
DELIMITER ;
-- ----------------------------------
DELIMITER //
CREATE PROCEDURE UpdateUser (
  IN p_UserID INT,
  IN p_Username VARCHAR(50),
  IN p_Password VARCHAR(100),
  IN p_CustomerID INT
)
BEGIN
  UPDATE users
  SET Username = p_Username, Password = p_Password, CustomerID = p_CustomerID
  WHERE UserID = p_UserID;
END //
DELIMITER ;
-- ----------------------------------------
DELIMITER //
CREATE PROCEDURE DeleteUser (
  IN p_UserID INT
)
BEGIN
  DELETE FROM users WHERE UserID = p_UserID;
END //
DELIMITER ;
-- -----------------------
DELIMITER //
CREATE PROCEDURE ViewAllUsers ()
BEGIN
  SELECT * FROM users;
END //
DELIMITER ;
-- ---------------------------------------
DELIMITER //
CREATE PROCEDURE DeleteCustomer (
  IN p_CustomerID INT
)
BEGIN
  DELETE FROM customers WHERE CustomerID = p_CustomerID;
END //
DELIMITER ;
-- ----------------------------------------
DELIMITER //
CREATE PROCEDURE GetWatchByMODEL (
  IN p_WatchModel VARCHAR(100)
)
BEGIN
  SELECT * FROM watches WHERE Model  = p_WatchModel;
END //
DELIMITER ;
-- -------------------------------
DELIMITER //
CREATE PROCEDURE GetOrderByID (
  IN p_OrderID INT
)
BEGIN
  SELECT * FROM orders WHERE OrderID = p_OrderID;
END //
DELIMITER ;
-- --------------------------------------
DELIMITER //
CREATE PROCEDURE UpdateUserPassword (
  IN p_UserID INT,
  IN p_Password VARCHAR(100)
)
BEGIN
  UPDATE users
  SET Password = p_Password
  WHERE UserID = p_UserID;
END //
DELIMITER ;

-- -----------------------------FUNCTIONS-------------------------------- 
DELIMITER //
CREATE FUNCTION GetCustomerEmail (
  p_CustomerID INT
) RETURNS VARCHAR(100)
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE email VARCHAR(100);
  SELECT Email INTO email
  FROM customers
  WHERE CustomerID = p_CustomerID;
  RETURN email;
END //
DELIMITER ;
-- ------------------------------------------
DELIMITER //
CREATE FUNCTION GetWatchDescription (
  p_WatchID INT
) RETURNS TEXT
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE description TEXT;
  SELECT Description INTO description
  FROM watches
  WHERE WatchID = p_WatchID;
  RETURN description;
END //
DELIMITER ;
-- -------------------------------------
DELIMITER //
CREATE FUNCTION GetInventoryAdjustmentQuantity (
  p_watchID INT
) RETURNS INT
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE quantityChange INT;
  SELECT QuantityChange INTO quantityChange
  FROM inventoryadjustments
  WHERE WatchID= p_watchID;
  RETURN quantityChange;
END 
//DELIMITER ;
-- -----------------------------------
DELIMITER //
CREATE FUNCTION GetOrderDate (
  p_OrderID INT
) RETURNS DATE
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE orderDate DATE;
  SELECT OrderDate INTO orderDate
  FROM orders
  WHERE OrderID = p_OrderID;
  RETURN orderDate;
END //
DELIMITER ;
-- --------------------------
drop function GetCustomerCity;
DELIMITER //
CREATE FUNCTION GetCustomerCity (
  p_CustomerID INT
) RETURNS VARCHAR(100)
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE city VARCHAR(100);
  SELECT City INTO city
  FROM customers
  WHERE CustomerID = p_CustomerID;
  RETURN city;
END //
DELIMITER ;
-- ----------------------------
DELIMITER //
CREATE FUNCTION GetAllWatchesByBrand (
  p_Brand VARCHAR(100)
  DETERMINISTIC
READS SQL DATA
) RETURNS TABLE
RETURN (
  SELECT * FROM watches WHERE Brand = p_Brand
);
DELIMITER ;
-- -----------------------------------------
DELIMITER //
CREATE FUNCTION GetAllWatchesByGender (
  p_Gender ENUM('Men', 'Women')
) RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT * FROM watches WHERE Gender = p_Gender
);
DELIMITER ;
-- ----------------------------------------
DELIMITER //
CREATE FUNCTION GetOrdersByCustomer (
  p_CustomerID INT
) RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT * FROM orders WHERE CustomerID = p_CustomerID
);
DELIMITER ;
-- ----------------------------------
DELIMITER //
CREATE FUNCTION GetSalesByDateRange (
  p_StartDate DATE,
  p_EndDate DATE
) RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT * FROM sales WHERE SaleDate BETWEEN p_StartDate AND p_EndDate
);
DELIMITER ;
-- --------------------------------------
DELIMITER //
CREATE FUNCTION GetWatchesByPriceRange (
  p_MinPrice DECIMAL(10,2),
  p_MaxPrice DECIMAL(10,2)
) RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT * FROM watches WHERE Price BETWEEN p_MinPrice AND p_MaxPrice
);
DELIMITER ;
-- --------------------------------------------
DELIMITER //
CREATE FUNCTION GetOrdersByDateRange (
  p_StartDate DATE,
  p_EndDate DATE
) RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT * FROM orders WHERE OrderDate BETWEEN p_StartDate AND p_EndDate
);
DELIMITER ;
-- --------------------------------------
DELIMITER //
CREATE FUNCTION GetCustomersByCity (
  p_City VARCHAR(100)
) RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT * FROM customers WHERE City = p_City
);
DELIMITER ;
-- --------------------------------------
DELIMITER //
CREATE FUNCTION GetSalesByOrderID (
  p_OrderID INT
) RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT * FROM sales WHERE OrderID = p_OrderID
);
DELIMITER ;
-- --------------------------------
DELIMITER //
CREATE FUNCTION GetCustomerFullAddress (
  p_CustomerID INT
) RETURNS VARCHAR(555)
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE fullAddress VARCHAR(555);
  SELECT CONCAT(Address, ', ', City, ', ', State, ', ', ZipCode, ', ', Country) INTO fullAddress
  FROM customers
  WHERE CustomerID = p_CustomerID;
  RETURN fullAddress;
END //
DELIMITER ;
-- -------------------------------
DELIMITER //
CREATE FUNCTION GetWatchInfo (
  p_WatchID INT
) RETURNS VARCHAR(255)
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE watchInfo VARCHAR(255);
  SELECT CONCAT(Brand, ' ', Model, ' (', Gender, ') - $', Price) INTO watchInfo
  FROM watches
  WHERE WatchID = p_WatchID;
  RETURN watchInfo;
END //
DELIMITER ;
-- ------------------------------------
DELIMITER //
CREATE FUNCTION GetCustomerOrdersCount (
  p_CustomerID INT
) RETURNS INT
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE ordersCount INT;
  SELECT COUNT(*) INTO ordersCount
  FROM orders
  WHERE CustomerID = p_CustomerID;
  RETURN ordersCount;
END //
DELIMITER ;
-- -----------------------------
DELIMITER //
CREATE FUNCTION GetCustomerSalesTotal (
  p_CustomerID INT
) RETURNS DECIMAL(10,2)
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE totalSales DECIMAL(10,2);
  SELECT SUM(TotalAmount) INTO totalSales
  FROM sales s
  JOIN orders o ON s.OrderID = o.OrderID
  WHERE o.CustomerID = p_CustomerID;
  RETURN totalSales;
END //
DELIMITER ;
-- --------------------------------
DELIMITER //
CREATE FUNCTION GetCustomerPurchaseHistory (
  p_CustomerID INT
) RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT o.OrderID, o.OrderDate, w.Brand, w.Model, s.TotalAmount
  FROM orders o
  JOIN watches w ON o.WatchID = w.WatchID
  JOIN sales s ON o.OrderID = s.OrderID
  WHERE o.CustomerID = p_CustomerID
);
DELIMITER ;
-- ---------------------------------------
DELIMITER //
CREATE FUNCTION GetWatchSalesHistory (
  p_WatchID INT
) RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT o.OrderID, o.CustomerID, c.FirstName, c.LastName, s.SaleDate, s.TotalAmount
  FROM orders o
  JOIN customers c ON o.CustomerID = c.CustomerID
  JOIN sales s ON o.OrderID = s.OrderID
  WHERE o.WatchID = p_WatchID
);
DELIMITER ;
-- -------------------------------------------
DELIMITER //
CREATE FUNCTION GetCustomerOrderAmount (
  p_CustomerID INT
) RETURNS DECIMAL(10,2)
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE totalAmount DECIMAL(10,2);
  SELECT SUM(s.TotalAmount) INTO totalAmount
  FROM sales s
  JOIN orders o ON s.OrderID = o.OrderID
  WHERE o.CustomerID = p_CustomerID;
  RETURN totalAmount;
END //
DELIMITER ;
-- ---------------------------------------
DELIMITER //
CREATE FUNCTION GetTopSellingWatches () RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT w.WatchID, w.Brand, w.Model, COUNT(o.OrderID) AS SalesCount
  FROM orders o
  JOIN watches w ON o.WatchID = w.WatchID
  GROUP BY w.WatchID, w.Brand, w.Model
  ORDER BY SalesCount DESC
);
DELIMITER ;
-- ------------------------
DELIMITER //
CREATE FUNCTION GetWatchesBelowStockLevel (
  p_StockLevel INT
) RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT w.WatchID, w.Brand, w.Model, SUM(i.QuantityChange) AS StockLevel
  FROM watches w
  JOIN inventoryadjustments i ON w.WatchID = i.WatchID
  GROUP BY w.WatchID, w.Brand, w.Model
  HAVING StockLevel < p_StockLevel
);
DELIMITER ;
-- ------------------------------------------
DELIMITER //
CREATE FUNCTION GetRecentOrders (
  p_Days INT
) RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT o.OrderID, o.OrderDate, c.FirstName, c.LastName, w.Brand, w.Model
  FROM orders o
  JOIN customers c ON o.CustomerID = c.CustomerID
  JOIN watches w ON o.WatchID = w.WatchID
  WHERE o.OrderDate >= DATE_SUB(CURDATE(), INTERVAL p_Days DAY)
);
DELIMITER ;
-- -------------------------------------------
DELIMITER //
CREATE FUNCTION GetWatchOrderDetails (
  p_WatchID INT
) RETURNS TABLE
DETERMINISTIC
READS SQL DATA
RETURN (
  SELECT o.OrderID, c.FirstName, c.LastName, o.OrderDate, s.TotalAmount
  FROM orders o
  JOIN customers c ON o.CustomerID = c.CustomerID
  JOIN sales s ON o.OrderID = s.OrderID
  WHERE o.WatchID = p_WatchID
);
DELIMITER ;
-- ----------------------------------------------------